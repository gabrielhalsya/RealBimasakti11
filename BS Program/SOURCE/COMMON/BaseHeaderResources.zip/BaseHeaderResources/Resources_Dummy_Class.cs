﻿using System;

namespace BaseHeaderResources
{
    public class Resources_Dummy_Class
    {

    }
}
