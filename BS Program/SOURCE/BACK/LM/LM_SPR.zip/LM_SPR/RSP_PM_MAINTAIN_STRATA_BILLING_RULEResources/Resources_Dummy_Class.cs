﻿using System;

namespace RSP_PM_MAINTAIN_STRATA_BILLING_RULEResources
{
    public class Resources_Dummy_Class
    {

    }
}
