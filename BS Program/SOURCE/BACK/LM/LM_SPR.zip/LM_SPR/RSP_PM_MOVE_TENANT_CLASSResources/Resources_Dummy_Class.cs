﻿using System;

namespace RSP_PM_MOVE_TENANT_CLASSResources
{
    public class Resources_Dummy_Class
    {

    }
}
