﻿using System;

namespace RSP_PM_UPLOAD_UTILITY_USAGE_WGResources
{
    public class Resources_Dummy_Class
    {

    }
}
