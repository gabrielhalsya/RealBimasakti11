﻿using System;

namespace RSP_PM_ACTIVE_INACTIVE_UNIT_PROMOTION_PRICEResources
{
    public class Resources_Dummy_Class
    {

    }
}
