﻿using System;

namespace RSP_PM_UPLOAD_UTILITY_USAGE_ECResources
{
    public class Resources_Dummy_Class
    {

    }
}
