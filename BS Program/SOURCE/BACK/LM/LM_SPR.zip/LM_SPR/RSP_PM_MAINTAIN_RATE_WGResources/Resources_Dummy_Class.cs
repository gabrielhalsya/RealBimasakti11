﻿using System;

namespace RSP_PM_MAINTAIN_RATE_WGResources
{
    public class Resources_Dummy_Class
    {

    }
}
