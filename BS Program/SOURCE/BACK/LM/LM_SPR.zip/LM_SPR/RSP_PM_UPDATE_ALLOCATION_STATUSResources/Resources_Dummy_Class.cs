﻿using System;

namespace RSP_PM_UPDATE_ALLOCATION_STATUSResources
{
    public class Resources_Dummy_Class
    {

    }
}
