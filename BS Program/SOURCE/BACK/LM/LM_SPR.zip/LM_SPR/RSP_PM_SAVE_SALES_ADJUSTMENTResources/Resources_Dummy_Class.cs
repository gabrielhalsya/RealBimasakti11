﻿using System;

namespace RSP_PM_SAVE_SALES_ADJUSTMENTResources
{
    public class Resources_Dummy_Class
    {

    }
}
