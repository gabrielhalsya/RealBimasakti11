﻿using System;

namespace RSP_PM_MAINTAIN_USER_PARAMResources
{
    public class Resources_Dummy_Class
    {

    }
}
