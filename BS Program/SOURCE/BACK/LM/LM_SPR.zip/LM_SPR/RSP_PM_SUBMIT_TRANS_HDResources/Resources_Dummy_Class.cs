﻿using System;

namespace RSP_PM_SUBMIT_TRANS_HDResources
{
    public class Resources_Dummy_Class
    {

    }
}
