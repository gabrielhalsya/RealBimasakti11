﻿using System;

namespace RSP_PM_SAVE_TRANS_HD_SUMMARYResources
{
    public class Resources_Dummy_Class
    {

    }
}
