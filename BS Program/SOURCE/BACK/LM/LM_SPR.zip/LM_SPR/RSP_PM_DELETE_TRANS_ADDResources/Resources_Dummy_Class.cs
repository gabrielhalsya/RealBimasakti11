﻿using System;

namespace RSP_PM_DELETE_TRANS_ADDResources
{
    public class Resources_Dummy_Class
    {

    }
}
