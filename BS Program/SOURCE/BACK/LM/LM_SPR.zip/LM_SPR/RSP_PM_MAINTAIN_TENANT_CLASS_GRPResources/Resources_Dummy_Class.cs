﻿using System;

namespace RSP_PM_MAINTAIN_TENANT_CLASS_GRPResources
{
    public class Resources_Dummy_Class
    {

    }
}
