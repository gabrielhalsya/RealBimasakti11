﻿using System;

namespace RSP_PM_GENERATE_WH_TAX_DEDUCTIONResources
{
    public class Resources_Dummy_Class
    {

    }
}
