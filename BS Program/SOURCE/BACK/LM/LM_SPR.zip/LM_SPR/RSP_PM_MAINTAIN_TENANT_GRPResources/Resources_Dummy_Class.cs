﻿using System;

namespace RSP_PM_MAINTAIN_TENANT_GRPResources
{
    public class Resources_Dummy_Class
    {

    }
}
