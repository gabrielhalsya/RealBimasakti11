﻿using System;

namespace RSP_PM_MAINTAIN_INVOICE_GRPResources
{
    public class Resources_Dummy_Class
    {

    }
}
