﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RSP_PM_MAINTAIN_TENANT_CTGResources
{
    public class Resources_Dummy_Class
    {
    }
}
