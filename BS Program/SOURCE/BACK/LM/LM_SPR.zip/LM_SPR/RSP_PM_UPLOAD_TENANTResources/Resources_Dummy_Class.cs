﻿using System;

namespace RSP_PM_UPLOAD_TENANTResources
{
    public class Resources_Dummy_Class
    {

    }
}
