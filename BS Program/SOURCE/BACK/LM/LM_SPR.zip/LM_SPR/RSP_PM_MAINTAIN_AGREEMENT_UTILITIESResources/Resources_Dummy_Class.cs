﻿using System;

namespace RSP_PM_MAINTAIN_AGREEMENT_UTILITIESResources
{
    public class Resources_Dummy_Class
    {

    }
}
