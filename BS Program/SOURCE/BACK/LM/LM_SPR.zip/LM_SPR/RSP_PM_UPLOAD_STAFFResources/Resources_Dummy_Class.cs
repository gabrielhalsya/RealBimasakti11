﻿using System;

namespace RSP_PM_UPLOAD_STAFFResources
{
    public class Resources_Dummy_Class
    {

    }
}
