﻿using System;

namespace RSP_PM_MAINTAIN_UNIT_PROMOTION_PRICEResources
{
    public class Resources_Dummy_Class
    {

    }
}
