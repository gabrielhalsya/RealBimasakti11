﻿using System;

namespace RSP_PM_MAINTAIN_RATE_OTResources
{
    public class Resources_Dummy_Class
    {

    }
}
