﻿using System;

namespace RSP_PM_SAVE_SALES_ADJUSTMENT_ALLOCResources
{
    public class Resources_Dummy_Class
    {

    }
}
