﻿using System;

namespace RSP_PM_SUBMIT_ALLOCATIONResources
{
    public class Resources_Dummy_Class
    {

    }
}   
