﻿using System;

namespace RSP_PM_MAINTAIN_TENANT_CLASSResources
{
    public class Resources_Dummy_Class
    {

    }
}
