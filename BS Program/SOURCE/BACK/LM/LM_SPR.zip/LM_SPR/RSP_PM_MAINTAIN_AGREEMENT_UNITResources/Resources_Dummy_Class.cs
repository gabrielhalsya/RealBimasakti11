﻿using System;

namespace RSP_PM_MAINTAIN_AGREEMENT_UNITResources
{
    public class Resources_Dummy_Class
    {

    }
}
