﻿using System;

namespace RSP_PM_MAINTAIN_PRICING_RATEResources
{
    public class Resources_Dummy_Class
    {

    }
}
