﻿using System;

namespace RSP_PM_SAVE_ALLOCATION
{
    public class Resources_Dummy_Class
    {

    }
}
