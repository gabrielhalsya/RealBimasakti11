﻿using System;

namespace RSP_PM_MAINTAIN_TENANTResources
{
    public class Resources_Dummy_Class
    {

    }
}
